function notify(message) {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;

  document.body.appendChild(toast);

  // Apply fadeIn animation
  toast.style.opacity = 0;
  toast.style.transition = "opacity 0.3s ease-in-out";
  setTimeout(() => {
    toast.style.opacity = 1;
  }, 10);

  setTimeout(() => {
    toast.classList.add('animate-fade-out');
    // Apply fadeOut animation
    toast.style.opacity = 0;
    setTimeout(() => {
      toast.remove();
    }, 300); // Time of fadeOut animation (adjust as needed)
  }, 3000); // Toast will disappear after 3 seconds (adjust as needed)
}

// Usage
notify("Hi, I am Snoaw, Welcome today!");
// Function to prevent default behavior for all forms
function preventFormDefault() {
  const forms = document.querySelectorAll("form");
  forms.forEach(formt => {
    formt.addEventListener("submit", e => {
      e.preventDefault();
    });
  });
}

// Function to handle submit button click for a specific form
function handleFormSubmit(formId) {
  const form = document.getElementById(formId);
  const continueBtn = form.querySelector(".submit-btn");
  const errorText = form.querySelector(".error-text");
  let loader = document.querySelector(".loader-container");
  loader.style.display = "flex";

  // Check internet speed/availability
  if (navigator.connection) {
    const connection = navigator.connection;
    if (connection.effectiveType === "slow-2g" || connection.downlink < 0.5) {
      // Internet speed is low
      alert("Internet speed is too slow. Please try again later.");
      loader.style.display = "none";
      return;
    }
    if (connection.type === "none" || connection.downlink === 0) {
      // Internet is unavailable
      alert("Internet is unavailable. Please check your connection and try again.");
      loader.style.display = "none";
      return;
    }
  }

  const xhr = new XMLHttpRequest();
  xhr.open("POST", form.action, true);
  xhr.onload = () => {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        const data = xhr.response;
        if (data === "success" || data.includes("success")) {
          successOD.play();
          errorText.innerHTML = "Successfully Done!";
          notify("Successfully Added!");
          form.reset();
          openPopup("Successfully", data, "success", "OK");
          loader.style.display = "none";
          reloadData();
        } else {
          errorText.innerHTML = data;
          notify(data);
          openPopup("Failed", data, "error", "OK");
          loader.style.display = "none";
        }
      }
    }
  };
  const formData = new FormData(form);
  xhr.send(formData);
}

// Call the function with the desired form class when the document is ready
document.addEventListener("DOMContentLoaded", () => {
  preventFormDefault(); // Replace "custom-form" with your desired form class
});
