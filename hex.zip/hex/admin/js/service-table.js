
    /*const social = {
        facebook:  "https://facebook.com/",
        instagram: "https://instagram.com/",
        github:    "https://github.com/",
        twitter:   "https://twitter.com/",
        linkedin:  "https://linkedin.com/in/"
    }*/


// [FUNCTION RELOAD DASHBOARD]
function reloadData1(){
  let loader = document.querySelector(".loader-container");
  loader.style.display = "flex";
    const xhr = new XMLHttpRequest();
xhr.open("POST", './js/exe-members.php', true);
xhr.onload = () => {
  if (xhr.readyState === XMLHttpRequest.DONE) {
    if (xhr.status === 200) {
      const data = xhr.response;
       eval(data);
    extractMemberTable('members');
    }
  }
};
xhr.send();

let xhr1 = new XMLHttpRequest();
xhr1.open("POST", './js/extract-orders.php', true);
xhr1.onload = () => {
if (xhr1.readyState === XMLHttpRequest.DONE) {
if (xhr1.status === 200) {
  const data = xhr1.response;
   eval(data);
extractOrdersTable('orders');
loader.style.display = "none";
}
}
};
xhr1.send();
}

function reloadData(){
    const xhr = new XMLHttpRequest();
xhr.open("POST", 'js/exe.php', true);
xhr.onload = () => {
  if (xhr.readyState === XMLHttpRequest.DONE) {
    if (xhr.status === 200) {
      const data = xhr.response;
       eval(data);
    extractServiceTable('hexen');
    }
  }
};
xhr.send();
reloadData1();
}
reloadData();
reloadData1();
// [EXTRACT] orders function
function extractOrdersTable(elementId){
    let element = document.getElementById(elementId);
    let i = 0;
    let ordersTable = '';
    if(orders.length>0){
    while(i<orders.length){
    ordersTable += `
    
    <tr>
        <td>${i+1}</td>
        <td>${orders[i].title}</td>
        <td>${orders[i].time}</td>
        <td>${orders[i].paymentStatus}</td>
        <td>
            <a href="#" class="btn btn-primary" onclick="viewOrders(${i})">View</a>
            <a href="#" class="btn btn-success" onclick="markOrder('${orders[i].orderId}', 'order', '1')">Done</a>
        </td>
    </tr>
    `;
    i++;
}
  } else{
    ordersTable = '<tr align="center"><td valign="top" colspan="5" class="dataTables_empty">No orders availabe to day.</td></tr>';
  }
  
  element.innerHTML = ordersTable;
    }
    function extractMessageTable() {
      let messageTable = '';
      let messageElement = document.getElementById('message');
  
      if (messages.length > 0) {
          for (let i = 0; i < messages.length; i++) {
              messageTable += `
                  <tr role="row" class="${i % 2 === 0 ? 'even' : 'odd'}">
                      <td>${i + 1}</td>
                      <td>${messages[i].name}</td>
                      <td>${messages[i].email}</td>
                      <td>${messages[i].message}</td>
                      <td>
                          <a href="#" class="btn btn-primary" onclick="openPopup('${messages[i].name}', '${messages[i].message}', 'success', 'Back')">View</a>
                          <a href="#" class="btn btn-danger" onclick="deleteMessage(${i})">Delete</a>
                      </td>
                  </tr>
              `;
          }
      } else {
          messageTable = '<tr align="center"><td valign="top" colspan="5">No messages available.</td></tr>';
      }
  
      messageElement.innerHTML = messageTable;
  }
  


extractOrdersTable('orders');
function markOrder(orderId, action, status){
    let postAction = `./php/functions/mark_order.php?id=${orderId}&action=${action}&status=${status}`; 
    let loader = document.querySelector(".loader-container");
    loader.style.display = "flex";
    const xhr = new XMLHttpRequest();
    xhr.open("GET", postAction, true);
    xhr.onload = () => {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const data = xhr.response;
          if (data === "success" || data.includes('success')) {
            successOD.play()
            openPopup('Successfully', "Successfully marked as done", 'success', 'OK');
            loader.style.display = "none";
            reloadData();
          } else {
            openPopup('Error', data, 'Unsuccessfully marked as done', 'OK');
            loader.style.display = "none";
          }
        }
      }
    };
    xhr.send();
}
function snoawDel(orderId, type){
    if(confirm(`Are sure you want to delete ${type}`)){
    let getAction = `./php/functions/delete.php?id=${orderId}&type=${type}`; 
    let loader = document.querySelector(".loader-container");
    loader.style.display = "flex";
    const xhr = new XMLHttpRequest();
    xhr.open("GET", getAction, true);
    xhr.onload = () => {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const data = xhr.response;
          if (data === "success" || data.includes('success')) {
            successOD.play();
            openPopup('Successfully', "Deleted Successfully", 'success', 'OK');
            loader.style.display = "none";
            reloadData();
          } else {
            openPopup('Error', data, 'warning', 'OK');
            loader.style.display = "none";
          }
        }
      }
    };
    xhr.send();
  }
}
// [EXTRACT] services function function
  function extractServiceTable(elementId){
    let element = document.getElementById(elementId);
    let oddeven = "odd";
    let i = 0;
    let serviceTable = '';
    while(i<services.length){
      if(oddeven == "odd"){
        oddeven = "even";
      } else{
        oddeven = "odd";
      }
    serviceTable += `
    
    <tr class="${oddeven}">
        <td>${i+1}</td>
        <td class="sorting_1">${services[i].title}</td>
        <td>${services[i].description}</td>
        <td>${services[i].price}</td>
        <td>
            <a href="#" class="btn btn-primary" onclick="editFormGen(${i})">Edit</a>
            <a href="#" class="btn btn-danger" onclick="snoawDel('${services[i].uniqueId}', 'service')">delete</a>
        </td>
    </tr>
    `;
    i++;
}
    element.innerHTML = serviceTable;
    }

// [EXTRACT] members into html table [FUNC]
      function extractMemberTable(elementId){
    let element = document.getElementById(elementId);
    let i = 0;
    let memberTable = '';
    while(i<members.length){
    memberTable += `
    
    <tr>
        <td>${i+1}</td>
        <td class="sorting_1">${members[i].names}</td>
        <td>${members[i].role}</td>
        <td>
            <a href="#" class="btn btn-primary" onclick="editTeamFormGen(${i})">Edit</a>
            <a href="#" class="btn btn-danger" onclick="snoawDel('${members[i].uniqueId}', 'team');">delete</a>
        </td>
    </tr>
    `;
    i++;
}
    element.innerHTML = memberTable;
    }

// [FUNCTION POP-UP]

      function openPopup(title, message, icon, btnName){
        ((btnName == '') || (!btnName)) && (btnName = "OK");
        Swal.fire({
          title: title,
          text: message,
          icon: icon,
          confirmButtonText: btnName,
        });
        let stopOd = document.querySelector('.swal2-confirm');
        stopOd.addEventListener('click', ()=>{
            successOD.pause();
        });
      }

// [ACTIVE MENU FUNCTION]
function lightMenu(){
    let menu = document.querySelectorAll('.nkiko');
    i = 0;
    while(i<menu.length){
        menu[i].classList.remove('dashboard-list-hov');
        i++;
    }
}

// [ARRANGE PHONE NUMBER FUNCTION]
function arrangeNum(){
    let telVar = tel.value.replaceAll(' ', '');
    var phoneTel = telVar.split('');
    let i = phoneTel.length;
    tel.value = '';
    while (i > 0){
        tel.value = phoneTel[i-1] + tel.value;
        if(i%4 == 0){
            tel.value = " " + tel.value;
        }
        i--;
    }
}

// [FUNCTION SHOW SEC]
function showSec(num, item){
    let i;
    let sections = document.querySelectorAll('#sec');
    i = 0;
    while(i<sections.length){
        sections[i].style.display = "none";
        i++;
    }
    sections[num-1].style.display = "block";
    let menu = document.querySelectorAll('.nkiko');
    lightMenu();
    menu[item-1].classList.add('dashboard-list-hov');
    //document.title = menu[item-1].title;
}

// [E]dit Service Form Generator
function editFormGen(index){
    let service = services[index];
    let form = `
    <div class="form-group">
    <div class="error-text"></div>
</div>
<div class="form-group">
    <label for="name">Service Name</label>
    <input class="form-control" type="text" name="name" placeholder="Enter Service Name" value="${service.title}">
</div>
<div class="form-group">
    <label>Service Category:</label>
    <select class="form-control" name="category" id="category">
        <option value="${service.category}">Change category from '${service.category}'</option>
        <option value="massage">Massage</option>
        <option value="waxing" >Waxing</option>
    </select>
</div>
<div class="form-group">
    <label for="duration">Service Duration(Time)</label>
    <input class="form-control" type="text" name="duration" placeholder="Enter Service Duration" value="${service.time}">
</div>

<!-- [H]idden input for  service id-->
<input hidden value="${service.uniqueId}" name="id">
<div class="form-group">
    <label for="cost">Service Price</label>
    <input class="form-control" type="text" name="cost" placeholder="Enter Service Price(Rfw)" value="${service.price}">
</div>
<div class="form-group">
    <label for="cost">Service Link</label>
    <input class="form-control" type="text" name="link" placeholder="Enter Service Link" value="${service.link}">
</div>
<div class="form-group">
    <label for="status">Service Status:</label>
    <select class="form-control" name="status" id="status">
        <option value="1">Choose Status (default 'visible')</option>
        <option value="1">Visible</option>
        <option value="0">Invisible</option>
    </select>
</div>
<div class="form-group">
    <label for="name">Service Cover</label>
    <input class="form-control" type="file" name="cover">
</div>
<div class="form-group">
    <label for="name">Service description</label>
    <textarea class="form-control" name="service_description" placeholder="Enter Service description...">${service.description}</textarea>
</div>

<div class="form-group">
    <button name="add" onclick=" handleFormSubmit('editserviceform')" class="submit-btn btn btn-primary" value="submit">Edit Service</button>
</div>
    `;
    editserviceform.innerHTML = form;
    showSec(8, 3);
    }

    // [FUNCTION EDIT TEAM]
    function editTeamFormGen(index){
    let member = members[index];
    let form = `
    <div class="form-group">
                            <div class="error-text"></div>
                        </div>
                        <div class="form-group">
                            <label for="member_name">Member Name*</label>
                            <input class="form-control" type="text" name="name" placeholder="Enter Member name" value="${member.names}">
                        </div>

                        <!-- [H]idden input for  service id-->
                        <input hidden value="${member.uniqueId}" name="id">
                        <div class="form-group">
                            <label for="email">Member email*</label>
                            <input class="form-control" type="email" name="email" placeholder="Enter Member Email" value="${member.email}">
                        </div>
                        <div class="form-group">
                            <label for="member_phone">Member phone*</label>
                            <input oninput="arrangeNum()" class="form-control" type="tel" id="tel" value="${member.phoneNumber}" name="phone" placeholder="Enter Member phome number ex: +25 0111 1111 11">
                        </div>
                        <div class="form-group">
                            <label for="role">Member role*</label>
                            <input class="form-control" type="text" name="role" placeholder="Enter Member Role" value="${member.role}">
                        </div>
                        <div class="form-group">
                            <label for="name">Member picture*</label>
                            <input class="form-control" type="file" name="cover" placeholder="Enter Service Name">
                        </div>
                        <h2>User Social Media</h2>

                        <div class="container">
                            <div class="form-group">
                                <input class="form-control" type="text" name="facebook" value="${member.facebook}"  placeholder="Link to your Facebook" value="https://facebook.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="Instagram" value="${member.instagram}" placeholder="Link to your Instagram" value="https://instagram.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="Twitter" value="${member.twitter}"   placeholder="Link to your Twitter" value="https://twitter.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="linkedIn" value="${member.linkedin}"  placeholder="Link to your linkedIn" value="https://linkedin.com/in/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="github" value="${member.github}"    placeholder="Link to your Github" value="http://github.com/">
                            </div>
                        </div>
                        <div class="form-group">
                            <button name="add_team"  onclick=" handleFormSubmit('editmemberform')" class="submit-btn btn btn-primary">Save Changes</button>
                        </div>
    `;
    editmemberform.innerHTML = form;
    showSec(9, 4);
    }

    // [FUNCTION] [VIEW ORDER]
    function viewOrders(orderID, elementId){
        if(!elementId){
            let elementId = document.getElementById('orderview');
        }
        let order = orders[orderID];
        let details = `
        <div class="container">
    <div class="title line-height-o">
      <h1 class="s-upper-text">Order information</h1>
      <p class="s-grey-text">2023-02-11</p>
    </div>
    <hr />
    <h2 class="s-padd">Order datails</h2>
    <div class="content s-padd12">
          <li>
            <b>Order title:</b>
            <span class="text">&nbsp;&nbsp; ${order.title}</span>
          </li>
          <li>
            <b>Order price:</b>
            <span class="text">&nbsp;&nbsp; ${order.price}</span>
          </li>
          <li>
            <b>Order destination:</b>
            <span class="text">&nbsp;&nbsp; Order location to them or to us</span>
          </li>
          <li>
            <b>Booked time:</b>
            <span class="text">&nbsp;&nbsp; ${order.time}</span>
          </li>
          <li>
            <b>Order Status:</b>
            <span class="text">&nbsp;&nbsp; <b class="s-green-color">${order.paymentStatus}</b>-<b>${order.orderStatus}</b></span>
          </li>
    </div>
    <h2 class="s-padd">Customer Info</h2>
    <div class="content s-padd12">
          <li>
            <b>Customer names:</b>
            <span class="text">&nbsp;&nbsp; ${order.clientNames}</span>
          </li>
          <li>
            <b>Customer email:</b>
            <span class="text">&nbsp;&nbsp; ${order.clientEmail}</span>
          </li>
          <li>
            <b>Phone number:</b>
            <span class="text">&nbsp;&nbsp; ${order.clientNumber}</span>
          </li>
          <li>
            <b>Customer location:</b>
            <span class="text">&nbsp;&nbsp; ${order.location}</span>
          </li>
    </div>
  </div>
        `;
        orderview.innerHTML = details;
    showSec(10, 5);
    }

