<?php
include("../php/conn.php");

$query = mysqli_query($conn, "SELECT * FROM `tbl_members`");
echo '
let social = {
    facebook:  "https://facebook.com/",
    instagram: "https://instagram.com/",
    github:    "https://github.com/",
    twitter:   "https://twitter.com/",
    linkedin:  "https://linkedin.com/in/"
};';
echo 'members = [';
while($row = mysqli_fetch_assoc($query)){
    $cover = $GLOBALS['ROOT'] . "admin/upload/team/" . $row['member_cover_pic']
?>
{
    names:       "<?=$row['member_name'] ?>    ",
    role:        "<?=$row['member_role'] ?>",
    cover:       "<?=$cover ?>",
    email:       "<?=$row['email_address'] ?>",
    phoneNumber: "<?=$row['phone_number'] ?>",
    uniqueId:    "<?=$row['id'] ?>",
    facebook:  social.facebook  + "<?= $row['facebook_link'] ?>",
    instagram: social.instagram + "<?= $row['instagram_link']?>",
    twitter:   social.twitter   + "<?= $row['twitter_link']  ?>",
    linkedin:  social.linkedin  + "<?= $row['linkedin_link'] ?>",
    github:    social.github    + "<?= $row['github_link']   ?>",
},
<?php
}
echo '];';
?>