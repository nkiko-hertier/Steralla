<?php
include("../php/conn.php");

$query = mysqli_query($conn, "SELECT * FROM `tbl_orders` ORDER BY `order_id` AND `order_date` DESC");
echo 'let orders = [';
while($row = mysqli_fetch_assoc($query)){
?>
{
    orderId:    "<?=$row['order_id'] ?>",
    title:      "<?=$row['order_description'] ?>",
    price:      "<?=$row['order_price'] ?>",
    time:       "<?=$row['order_date'] ?>",
    location:   "<?=$row['order_location'] ?>",
    clientNames:"<?=$row['clinet_names'] ?>",
    clientNumber:  "<?=$row['phone_number'] ?>",
    clientEmail:   "<?=$row['email_address'] ?>",
    orderStatus:   "<?php if($row['order_status'] == '0'){echo "undone";} else{echo "done";} ?>",
    paymentStatus: "<?php if($row['payment_status'] == '0'){echo "Unpaid";} else{echo "Paid";} ?>",
},
<?php
}
echo '];';
?>