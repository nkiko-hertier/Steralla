<?php
include("../php/conn.php");

// Fetch data from tbl_services
$query_services = mysqli_query($conn, "SELECT * FROM `tbl_services` ORDER BY `s_id` DESC");
echo 'services = [';
while ($row = mysqli_fetch_assoc($query_services)) {
    $title = $row['s_title'];
    $slag = str_replace(' ', '-', $title);

    // Remove line breaks from the description
    $description = str_replace(array("\n", "\r"), '', $row['s_description']);
    ?>
    {   
        title: "<?= $row['s_title'] ?>",
        price: "<?= $row['s_cost'] ?>",
        time: "<?= $row['s_duration'] ?>",
        description: "<?= $description ?>",
        category: "<?= $row['Type'] ?>",
        link: "<?= $row['s_link'] ?>",
        id: "<?= $slag ?>",
        uniqueId: "<?= $row['s_unique_id'] ?>",
        cover: "<?= $row['cover'] ?>"
    },
    <?php
}
echo '];';

// Fetch data from tbl_messages
$query_messages = mysqli_query($conn, "SELECT * FROM `tbl_messages` ORDER BY `id` DESC");
echo 'messages = [';
while ($row = mysqli_fetch_assoc($query_messages)) {
    $message = str_replace(array("\n", "\r"), '', $row['message']);
    $name = $row['name'];
    $email = $row['email'];
    $status = $row['status'];
    ?>
    {
        message: "<?= $message?>",
        name: "<?= $name ?>",
        email: "<?= $email ?>",
        status: "<?= $status ?>"
    },
    <?php
}
echo '];';
?>
