<?php 
  session_start();
  include_once "php/conn.php";
  include_once "php/functions.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/flex.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/loader.css">

    <!-- [S]tart -->
        <link rel="stylesheet" href="../libs/css/jquery.dataTables.min.css?v=2">
        <script src="../css/popper.min.js"></script>
        <script src="../libs/js/jquery.min.js"></script>
        <script src="../libs/js/bootstrap.min.js"></script>
        <script src="../libs/js/jquery.dataTables.min.js"></script>
        <script src="../libs/js/dataTables.bootstrap.min.js"></script>
    <!-- [E]nd -->
    <!--<script src="../css/popper.min.js"></script>
    <script src="../css/jquery.js"></script>
    <script src="../css/bootstrap.min.js"></script>-->
  <link rel="stylesheet" href="./css/sweetalert2.min.css">
  <style>
    #orderview .content li{
        text-align: left;
    }
    .dataTables_wrapper .row:nth-child(2){
        overflow-x: auto;
    }
    .dataTables_wrapper .row:nth-child(1){
        display: flex;
    }
  </style>
    <title>Snoaw Dashboard |</title>
</head>
<body>
    <audio src="./audio/good-night-160166.mp3" id="successOD"></audio>
    <div class="loader-container flex-center">
        <div class="loader"></div>
    </div>
    <div class="dash-container flex-top">
    <header class="flex-btwn dark-back f-width">
        <div class="logo f-width s-padd1 flex-start">
            <i class="fab fa-apple sec-back s-padd1 s-radius f-border "></i>
            &nbsp;<h6>Dashboard</h6>
        </div>
        <div class="logo f-width s-padd1  flex-end">
            <div class="dropdown show">
                <a class="s-pointer sec-back s-padd1 s-border dropdown-toggle dropdown-toggle-split" id="dropDownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    
                <i class="fa fa-user dark-back s-padd1 s-radius f-border"></i> <span class="u-name"><?=$_SESSION['user_name'] ?></span>
                </a>
                <div class="dropdown-menu sec-back" aria-labelledby="dropDownMenuLink">
                    <a href="#" class="dropdown-item">My profile</a>
                    <a href="./php/logout.php?logout_id=<?=$_SESSION['unique_id']?>" class="dropdown-item">Logout</a>
                    <a href="#" class="dropdown-item">Dashboard</a>
                </div>
            </div>
        </div>
    </header>
    <main class="main sec-back f-height flex-top">
        <div class="dash-row">
            <ul class="dashboard-list">
                <li class="menu flex-end"><a href="#" class="padd-left"><i class="fa fa-bars"></i> </a></li>
                <li class="nkiko" title="Dashboard - Home"     onclick="showSec(1,1)"><i class="fa fa-home s-padd"></i><a href="#">Dashboard</a></li>
                <li class="nkiko" title="Dashboard - Services" onclick="showSec(2,2)"><i class="fa fa-wheelchair s-padd"></i><a href="#">Services</a></li>
                <li class="nkiko" title="Dashboard - Massages" onclick="showSec(3,3)"><i class="fab fa-facebook-messenger s-padd"></i><a href="#">Massages</a></li>
                <li class="nkiko" title="Dashboard - Team Settings" onclick="showSec(4,4)"><i class="fa fa-user s-padd"></i><a href="#">Team Settings</a></li>
                <li class="nkiko" title="Dashboard - Orders"       onclick="showSec(5,5)"><i class="fa fa-industry s-padd"></i><a href="#">Orders</a></li>
            </ul>
        </div>
        <div class="dash-row s-overflowY">
            <!--[S]ection 1 for dashboard home-->
            <?php include_once("php/sections/home.php")?>

            <!--[S]ection 2 for service magement-->
            <?php include_once("php/sections/manage_services.php")?>

            <!--[S]ection 3 for Massages-->
            <?php include_once("php/sections/manage_messages.php")?>
            
            <!--[S]ection 4 for Team management-->
            <?php include_once("php/sections/manage_teams.php")?>
            
            <!--[S]ection 5 for Website Settings-->
            <?php include_once("php/sections/manage_orders.php")?>

            <!--[S]ection 6 for Add Services-->
            <?php include_once("php/sections/add_service.php")?>
            
            <!--[S]ection 7 for Add Team-->
            <?php include_once("php/sections/add_team.php")?>
            
            <!--[S]ection 8 for Edit Service-->
            <?php include_once("php/sections/edit_service.php")?>

            <!-- [S]ection 9 for edit service -->
            <?php include_once("php/sections/edit_team.php")?>

            <!-- [S]ection 10 for edit service -->
            <?php include_once("php/sections/view_order.php")?>
        </div>
    </main>
    </div>
    <script>
        let services;
    </script>
   <script src="./css/dist_sweetalert2.js"></script>
    <script src="./js/exe.php"></script>
    <script src="./js/exe-members.php"></script>
    <script src="./js/extract-orders.php"></script>
    <script src="./js/service-table.js"></script>
    <script src="./js/proceed_form.js"></script>
    <script src="../js/dup.lib.js"></script>
    <script src="../js/chart.js"></script>
    <script>
        
        showSec(1, 1);
reloadData();
reloadData1();
        extractServiceTable('hexen');
        extractOrdersTable('orders');
        extractMemberTable('members')
        
    let tables = document.querySelectorAll('table');
    i = 0;
    while (i<tables.length){
        tables[i].style.width = "100%";
        i++;
    }

$(document).ready( function () {
    $('#myTables').DataTable();
    $('#myTables1').DataTable();
    $('#myTable').DataTable();
    genChart('analyticsChart', 'line', 'views', '<?=$labelData?>');
    genChart('analyticsChart1', 'bar', 'views', '<?=$pageData?>');
    genChart('citydata', 'pie', 'views', '<?=$cityData?>');
    
    let searchFields = document.querySelectorAll('#filtersearch');
    i = 0;
    while (i<searchFields.length){
        searchFields[i].placeholder = "Search by keyword...";
        i++;
    }
    } );
    extractMessageTable();
    
    </script>
</body>
</html>