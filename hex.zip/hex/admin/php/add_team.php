<?php
    include_once("conn.php");
        // [G]etting form data
        $name      = $_POST['name'];
        $role      = $_POST['role'];
        $phone     = $_POST['phone'];
        $email     = $_POST['email'];

        $facebook_link  = explode('/', $_POST['facebook']);
        $Instagram_link = explode('/', $_POST['Instagram']);
        $Twitter_link   = explode('/', $_POST['Twitter']);
        $linkedIn_link  = explode('/', $_POST['linkedIn']);
        $github_link    = explode('/', $_POST['github']);   

        $facebook  = end($facebook_link);
        $Instagram = end($Instagram_link);
        $Twitter   = end($Twitter_link);
        $linkedIn  = end($linkedIn_link);
        $github    = end($github_link);   

        // [G]etting cover picture
		$pic_name 	      = $_FILES['cover']['name'];
		$pic_tmp  	      = $_FILES['cover']['tmp_name'];
        $extensions       =        ["jpeg", "png", "jpg", "PNG", "JPEG", "JPG"];
		$pic_extension    = pathinfo($pic_name, PATHINFO_EXTENSION);
		$pic_upload_name  = "snoaw-" . uniqid() . "." . $pic_extension;
		$destination      = "../../images/uploads/team/" . $pic_upload_name;
        $verify_image     = in_array($pic_extension, $extensions);


        if(!empty($name) && !empty($role) && !empty($facebook) && !empty($linkedIn) && !empty($Twitter) && !empty($pic_name)){
            if(!empty($Instagram) && !empty($github)){
                // [C]heking if team/member exists
                $check_query    = mysqli_query($conn, "SELECT * FROM `tbl_members` WHERE `member_name`='$name'");
                if(!mysqli_num_rows($check_query)){
                    if($verify_image === true){
                        if(move_uploaded_file($pic_tmp, $destination)){
                            $query = mysqli_query($conn, "INSERT INTO `tbl_members`(`id`, `member_name`, `member_role`, `member_cover_pic`, `facebook_link`, `instagram_link`, `twitter_link`, `linkedin_link`, `github_link`, `email_address`, `phone_number`) VALUES ('','$name','$role','$pic_upload_name','$facebook','$Instagram','$Twitter','$linkedIn','$github','$email','$phone')");
                            if($query){
                                echo "success";
                            }
                        } else {
                            echo "Oops something went wrong!";
                        }

                    } else {
                        echo "Only png jpg or jpeg allowed!";
                    }
                } else {
                    echo "Member exists!";
                }

            } else {
                echo "Fill one or both Instagram and Github!";
            }
        } else {
            echo "fill all required <red>*</red> fields!";
        }