<?php
    include_once("../security.php");
    if (isset($_GET['id'])){
        $id    = $_GET['id'];   #--unique code for service or member 
        $type  = $_GET['type']; #--this may be member or services
        if($type == "service"){
            //check if service booked
            $query = mysqli_query($conn, "SELECT * FROM `tbl_orders` WHERE `service_id`='$id'");
            if (mysqli_num_rows($query)>0){
                echo "Can't delete service with undone order(s).";
                exit();
            } else {
                $query = mysqli_query($conn, "DELETE FROM `tbl_services` WHERE `s_unique_id`='$id'");
                if($query){
                    echo "success";
                } else{
                    echo "Service unsuccesssfully deleted!";
                }
            }
        } elseif($type == "team"){
            $query = mysqli_query($conn, "DELETE FROM `tbl_members` WHERE `id`='$id'");
            if($query){
                echo "success";
            } else {
                echo "Member unsuccesfully deleted!";
            }
        }
    }
?>