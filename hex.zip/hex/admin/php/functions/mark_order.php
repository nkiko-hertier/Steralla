<?php
    include_once("../conn.php");
    include_once("../security.php");
    if(isset($_GET['id']) && isset($_GET['action'])){
        $order_id = $_GET['id'];
        $status    = $_GET['status'];
        $action   = $_GET['action'];
        //action may be marking payment or order as done
    }
    if($action == 'order'){
        $query = mysqli_query($conn, "UPDATE `tbl_orders` SET `order_status`='$status' WHERE `order_id`='$order_id'");
        if($query){
            echo "success";
        } else {
            echo "Failed to mark order as done";
        }
    } else {
        $query = mysqli_query($conn, "UPDATE `tbl_orders` SET `payment_status`='$status' WHERE `order_id`='$order_id'");
        if($query){
            echo "sucess";
        } else {
            echo "Failed to mark order as done";
        }

    }

?>