<?php
include_once("conn.php");
    $order_description = mysqli_real_escape_string($conn, $_POST['description']);
    $order_price       = mysqli_real_escape_string($conn, $_POST['amount']);
    $order_id          = mysqli_real_escape_string($conn, $_POST['tx_ref']);
    $first_name        = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name         = mysqli_real_escape_string($conn, $_POST['last_name']);
    $clinet_names      = $first_name . " " . $last_name;
    $email_address     = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number      = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $order_date        = mysqli_real_escape_string($conn, $_POST['date']);
    $order_location    = mysqli_real_escape_string($conn, $_POST['location']);
    $service_id        = mysqli_real_escape_string($conn, $_POST['serviceid']);
    $order_id          = uniqid("heklo");
    $sql   = "INSERT INTO `tbl_orders`(`tx_ref`, `service_id`, `order_date`, `order_location`, `order_description`, `order_price`, `clinet_names`, `phone_number`, `email_address`, `order_status`, `payment_status`) VALUES ('$order_id','$service_id','$order_date','$order_location','$order_description','$order_price','$clinet_names','$phone_number','$email_address','','')";
    $query = mysqli_query($conn, $sql);
    if($query){
        echo "success";
    }else{
        echo "failed";
    }
?>