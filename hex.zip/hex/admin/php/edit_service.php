<?php
    include_once('conn.php');
    error_reporting(0);
    
        $id            = mysqli_real_escape_string($conn, $_POST['id']);
        $name          = mysqli_real_escape_string($conn, $_POST['name']);
        $category      = mysqli_real_escape_string($conn, $_POST['category']);
        $description   = mysqli_real_escape_string($conn, $_POST['service_description']);
        $cost          = mysqli_real_escape_string($conn, $_POST['cost']);
        $duration      = mysqli_real_escape_string($conn, $_POST['duration']);
        $link          = mysqli_real_escape_string($conn, $_POST['link']);
        $status    = mysqli_real_escape_string($conn, $_POST['status']);
        $service_id    = mysqli_real_escape_string($conn, $_POST['id']);

        if (!($_FILES['cover']['name'] == '')) {
            $pic_name      = $_FILES['cover']['name'];
            $pic_tmp       = $_FILES['cover']['tmp_name'];
            $pic_extension = pathinfo($pic_name, PATHINFO_EXTENSION);
            $uploaded_img  = "snoaw-" . uniqid() . "." . $pic_extension;
            $destination   = "../../images/uploads/services/" . $uploaded_img;
            $extensions    = ["jpeg", "png", "jpg"];


            if (in_array(strtolower($pic_extension), $extensions)) {
                if (move_uploaded_file($pic_tmp, $destination)) {
                    $select_img_name = mysqli_query($conn, "SELECT * FROM `tbl_services` WHERE `s_unique_id`='$service_id'");
                    $old_img = mysqli_fetch_assoc($select_img_name)['cover'];
                    unlink("../../images/uploads/services/" . $old_img);
                } else {
                    echo "Oops, Something went wrong!";
                    exit();
                }
            } else {
                echo "Only '.jpeg', '.jpg', '.png' accepted";
                exit();
            }
        }

        if (!empty($name) && !empty($description) && !empty($cost) && !empty($link) && !empty($duration)) {
            $update_query = "UPDATE `tbl_services` SET `s_title`='$name', `s_description`='$description', `s_cost`='$cost', `s_duration`='$duration', `s_link`='$link', `status`='$status', `Type`='$category'";
            if (!empty($pic_name)) {
                $update_query .= ", `cover`='$uploaded_img'";
            }
            $update_query .= " WHERE `s_unique_id`='$service_id'";

            if (mysqli_query($conn, $update_query)) {
                echo "success";
            } else {
                echo "Failed to update service!";
            }
        } else {
            echo "Fill all inputs and try again!";
        }
?>
