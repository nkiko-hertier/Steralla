<?php
    session_start();
    include_once "conn.php";

    if(!(isset($_SESSION['unique_id']))){
        //header("location: {$GLOBALS['ROOT']}");
        echo "you're logged out. Try refleshing page.";
        exit();
    }
?>