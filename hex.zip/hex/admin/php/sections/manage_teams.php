
<section id="sec" class="container">
                <h1 class="flex-btwn">
                    <c>Manage Teams</c> 
                    <i onclick="showSec(7,4)" class="fa fa-plus-circle s-green-color s-pointer"></i>
                </h1>
                <hr>
                <div id="myTable_wrapper" class="dataTables_wrapper no-footer">
                <table class="table table-fluid dataTable no-footer" id="myTables2" role="grid" aria-describedby="myTable_info">
                    <thead>
                        <tr role="row">
                            <td>Id</td>
                            <td class="fit-width btn-width">Name</td>
                            <td class="fit-width">Role</td>
                            <td class="btn-width">Actions</td>
                        </tr>
                    </thead>
                    <tbody id="members">
                        <tr role="row">
                            <td>#</td>
                            <td>Nkiko&nbsp;Hertier</td>
                            <td>Developer</td>
                            <td>
                                <a href="#" class="btn btn-primary">Edit</a>
                                <a href="#" class="btn btn-danger" onclick="confirm('Are sure you want to remove?')">Remove</a>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr role="row">
                            <td>id</td>
                            <td>name</td>
                            <td>Role</td>
                            <td>actions</td>
                        </tr>
                    </tfoot>
                </table>
                </div>
                <div class="padd-space"></div>
            </section>