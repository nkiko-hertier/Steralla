
<section id="sec" class="container">
    <div id="orderview"></div>
    <a href="#" class="btn btn-success" onclick="markOrder('1', 'order', '1')">mark As done</a>
    <div class="padd-space"></div>
</section>