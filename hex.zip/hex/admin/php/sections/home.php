<section id="sec" class="home container">
                <h1>Dashboard Home</h1>
                <hr>
                <div id="cards" class="cards-container flex-center wrap">
                    <div class="card align-center">
                        <h1><?=countRows("tbl_services", $conn)?></h1>
                        <p>Products</p>
                    </div>
                    

                    
                    <div class="card align-center">
                        <h1><?=countRows("tbl_orders", $conn)?></h1>
                        <p>Tatal Orders</p>
                    </div>

                    <div class="card align-center">
                        <h1><?=countRows("tbl_members", $conn)?></h1>
                        <p>Team Members</p>
                    </div>

                    
                    <div class="card align-center">
                        <h1><?=countRows("tbl_messages", $conn)?></h1>
                        <p>Messages</p>
                    </div>
                </div>
                <h1>Website analytics</h1>
                <hr>
                <div style="display: flex;" class="wrap">
                <div style="width: 50%;">
                    <div style="width: auto; margin: 0 auto;display: block;">
                        <canvas id="analyticsChart"></canvas>
                    </div>
                    <div style="width: auto; margin: 0 auto;display: block;">
                        <canvas id="analyticsChart1"></canvas>
                    </div>
                </div>
                    <div style="width: 50%; margin: 0 auto;">
                        <canvas id="citydata"></canvas>
                    </div>
</div>
                    <script>
        // PHP data to JavaScript
        <?php

            // Fetch analytics data from the database grouped by month
            $select_query = "SELECT DATE_FORMAT(date, '%Y-%m') as month, COUNT(*) as count FROM user_analytics GROUP BY month";
            $result = mysqli_query($conn, $select_query);

            $monthData = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $monthData[$row['month']] = $row['count'];
            }
            $select_query = "SELECT city, COUNT(*) as count FROM user_analytics GROUP BY city";
            $result = mysqli_query($conn, $select_query);

            $cityData = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $cityData[$row['city']] = $row['count'];
            }

            //[F]etch pages anayltics
            $select_query = "SELECT page, COUNT(*) as count FROM user_analytics GROUP BY page";
            $result = mysqli_query($conn, $select_query);

            $pageData = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $pageData[$row['page']] = $row['count'];
            }
            mysqli_close($conn);
           $labelData = json_encode(array_keys($monthData)) . '&' . json_encode(array_values($monthData));
           $cityData = json_encode(array_keys($cityData)) . '&' . json_encode(array_values($cityData));
           $pageData = json_encode(array_keys($pageData)) . '&' . json_encode(array_values($pageData));
        ?>
        // JavaScript Chart.js code
        function genChart(chartId, type, snoawLabels, labelsData){
        let labelData = labelsData.replace("'", "");
        labelData =  labelData.split('&');
        var ctx = document.getElementById(chartId).getContext('2d');
        var chart = new Chart(ctx, {
            type: type,
            data: {
                labels: JSON.parse(labelData[0]),
                datasets: [{
                    label: snoawLabels,
                    data: JSON.parse(labelData[1]),
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                },]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    </script>
                <div class="padd-space"></div>
            </section>
            