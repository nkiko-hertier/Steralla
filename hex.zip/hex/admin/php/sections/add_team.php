
<section id="sec" class="container">
                <h1>Add New Team</h1>
                <hr>
                <div class="conatiner s-overflowX">
                    <form action="./php/add_team.php" method="post" id="form" class="s-padd12" enctype="multipart/form-data">
                        <div class="form-group">
                            <div class="error-text"></div>
                        </div>
                        <div class="form-group">
                            <label for="member_name">Member Name*</label>
                            <input class="form-control" type="text" name="name" placeholder="Enter Member name">
                        </div>
                        <div class="form-group">
                            <label for="email">Member email*</label>
                            <input class="form-control" type="email" name="email" placeholder="Enter Member Email">
                        </div>
                        <div class="form-group">
                            <label for="member_phone">Member phone*</label>
                            <input oninput="arrangeNum()" class="form-control" type="tel" id="tel" name="phone" placeholder="Enter Member phome number ex: +25 0111 1111 11">
                        </div>
                        <div class="form-group">
                            <label for="role">Member role*</label>
                            <input class="form-control" type="text" name="role" placeholder="Enter Member Role">
                        </div>
                        <div class="form-group">
                            <label for="name">Member picture*</label>
                            <input class="form-control" type="file" name="cover" placeholder="Enter Service Name">
                        </div>
                        <h2>User Social Media</h2>

                        <div class="container">
                            <div class="form-group">
                                <input class="form-control" type="text" name="facebook"  placeholder="Link to your Facebook" value="https://facebook.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="Instagram" placeholder="Link to your Instagram" value="https://instagram.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="Twitter"   placeholder="Link to your Twitter" value="https://twitter.com/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="linkedIn"  placeholder="Link to your linkedIn" value="https://linkedin.com/in/">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="github"    placeholder="Link to your Github" value="http://github.com/">
                            </div>
                        </div>
                        <div class="form-group">
                            <button name="add_team"  onclick=" handleFormSubmit('form')" class="submit-btn btn btn-primary">Add Member</button>
                        </div>
                    </form>
                </div>
                <div class="padd-space"></div>
            </section>
            