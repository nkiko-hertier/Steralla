

<section id="sec" class="container">
                <h1>Edit Member</h1>
                <hr>
                <div class="conatiner s-overflowX">
                    <form action="./php/edit_team.php" method="post" id="editmemberform" class="s-padd12" enctype="multipart/form-data">

                    </form>
                </div>
                <div class="padd-space"></div>
            </section>