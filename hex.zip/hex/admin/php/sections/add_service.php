
<section id="sec" class="container">
                <h1>Add New service</h1>
                <hr>
                <div class="conatiner s-overflowX">
                    <form action="php/add_service.php" id="form1" method="post" class="s-padd12 form1" enctype="multipart/form-data">
                        <div class="form-group">
                            <div class="error-text"></div>
                        </div>
                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input class="form-control" type="text" name="name" placeholder="Enter Product Name">
                        </div>
                        <div class="form-group">
                            <label>Product Category:</label>
                            <select class="form-control" name="category" id="category">
                                <option value="massage">Massage</option>
                                <option value="waxing" >Waxing</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cost">Product Price</label>
                            <input class="form-control" type="text" name="cost" placeholder="Enter Product Price(Rfw)">
                        </div>
                        <div class="form-group">
                            <label for="duration">Product Duration(Time)</label>
                            <input class="form-control" type="text" name="duration" placeholder="Enter Product Duration">
                        </div>
                        <div class="form-group">
                            <label for="cost">Product Link</label>
                            <input class="form-control" type="text" name="link" placeholder="Enter Product Link">
                        </div>
                        <div class="form-group">
                            <label for="name">Product Cover</label>
                            <input class="form-control" type="file" name="cover" placeholder="Enter Product Name">
                        </div>
                        <div class="form-group">
                            <label for="name">Product description</label>
                            <textarea class="form-control" name="service_description" placeholder="Enter Product description..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <button name="add" onclick=" handleFormSubmit('form1')" class="submit-btn btn btn-primary" value="submit">Add Service</button>
                        </div>
                    </form>
                </div>
                <div class="padd-space"></div>
            </section>