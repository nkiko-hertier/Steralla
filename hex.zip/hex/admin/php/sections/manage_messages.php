
<section id="sec" class="container">
                <h1>Messages</h1>
                <hr>
                <div id="myTable_wrapper" class="dataTables_wrapper no-footer">
                <table class="table table-fluid dataTable no-footer" id="myTables1" role="grid" aria-describedby="myTable_info">
                    <thead>
                        <tr role="row">
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables1" rowspan="1" colspan="1" aria-sort="ascending" >id</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables1" rowspan="1" colspan="1" aria-sort="ascending"  class="btn-width">Name</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables1" rowspan="1" colspan="1" aria-sort="ascending"  style="width: fit-content;">Email</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables1" rowspan="1" colspan="1" aria-sort="ascending"  class="des-width">Message</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables1" rowspan="1" colspan="1" aria-sort="ascending"  class="btn-width">actions</th>
                        </tr>
                    </thead>
                    <tbody id="message">
                        <tr role="row" class="odd">
                            <td>#</td>
                            <td>Nkiko Hertier</td>
                            <td>afrigames123@gmail.com</td>
                            <td>Hello Compony Team...</td>
                            <td>
                                <a href="#" class="btn btn-primary">View</a>
                                <a href="#" class="btn btn-danger" onclick="confirm('Are sure you want to delete?')">delete</a>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr role="row">
                            <td>id</td>
                            <td>name</td>
                            <td>Email</td>
                            <td>Message</td>
                            <td>actions</td>
                        </tr>
                    </tfoot>
                </table>
                </div>
                <div class="padd-space"></div>
            </section>