
<section id="sec" class="container">
                <h1 class="flex-btwn">
                    <c>Manage Orders</c> 
                    <i onclick="showSec(6,2)" class="fa fa-plus-circle s-green-color s-pointer"></i>
                </h1>
                <hr>
                <div id="myTable_wrapper" class="dataTables_wrapper no-footer">
                <table class="table table-fluid dataTable no-footer" id="myTable" role="grid" aria-describedby="myTable_info">
                    <thead>
                        <tr role="row">
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending">id</td>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending">Serviece name</td>
                            <th class="sorting_asc des-width" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending">Order time</td>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending">status</td>
                            <th class="sorting_asc btn-width" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending">actions</th>
                        </tr>
                    </thead>
                    <tbody id="orders">

                    </tbody>
                    <tfoot>
                        <tr role="row">
                            <td>id</td>
                            <td>Product Name</td>
                            <td>Order time</td>
                            <td>status</td>
                            <td>actions</td>
                        </tr>
                    </tfoot>
                </table>
                </div>
                <div class="padd-space"></div>
            </section>
            