
<section id="sec" class="container">
                <h1 class="flex-btwn">
                    <c>Manage Products</c>
                    <i onclick="showSec(6,2)" class="fa fa-plus-circle s-green-color s-pointer">J</i>
                </h1>
                <hr>
                <div id="myTable_wrapper" class="dataTables_wrapper no-footer">
                <table class="table table-fluid dataTable no-footer" id="myTables" role="grid" aria-describedby="myTable_info">
                    <thead>
                        <tr role="row">
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Password: activate to sort column ascending" >id</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Password: activate to sort column ascending" >name</th>
                            <th class="sorting_asc des-width" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Password: activate to sort column ascending">description</th>
                            <th class="sorting_asc" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Password: activate to sort column ascending" >Cost</th>
                            <th class="sorting_asc btn-width" tabindex="0" aria-controls="myTables" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Password: activate to sort column ascending">actions</th>
                        </tr>
                    </thead>
                    <tbody id="hexen">

                    </tbody>
                    <tfoot>
                        <tr role="row">
                            <td>id</td>
                            <td>name</td>
                            <td>description</td>
                            <td>Cost</td>
                            <td>actions</td>
                        </tr>
                    </tfoot>
                </table>
                </div>
                <div class="padd-space"></div>
            </section>
            