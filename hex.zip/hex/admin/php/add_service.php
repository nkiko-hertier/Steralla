<?php
    include_once('conn.php');
	//if ($_SERVER['REQUEST_METHOD']=="POST") {
		if (isset($_POST['name'])) {
		//getting form data
        $name          = mysqli_real_escape_string($conn, $_POST['name']);
        $category      = mysqli_real_escape_string($conn, $_POST['category']);
        $description   = mysqli_real_escape_string($conn, $_POST['service_description']);
        $cost          = mysqli_real_escape_string($conn, $_POST['cost']);
        $duration      = mysqli_real_escape_string($conn, $_POST['duration']);
        $link          = mysqli_real_escape_string($conn, $_POST['link']);
		if(isset($_FILES['cover'])){
			$pic_name 	   = $_FILES['cover']['name'];
			$pic_tmp  	   = $_FILES['cover']['tmp_name'];

			//file upload configurations
			$pic_extension = pathinfo($pic_name, PATHINFO_EXTENSION);
			$uploaded_img  = "snoaw-" . uniqid() . "." . $pic_extension;
			$destination   = "../../images/uploads/services/" . $uploaded_img;
		} else{
			echo "Plz, upload cover picture!";
			exit();
		}

		//checking wether Service exist
		$query1        = mysqli_query($conn, "SELECT * FROM `tbl_services` WHERE `s_title`='$name'" );
		if(!mysqli_num_rows($query1)){
			//
			if(!empty($name) && !empty($description) && !empty($name) && !empty($cost) && !empty($link) && !empty($pic_name) && !empty($duration)){
    			$extensions = ["jpeg", "png", "jpg", "PNG", "JPEG", "JPG"];
    			if(in_array($pic_extension, $extensions) === true){
    			if(move_uploaded_file($pic_tmp, $destination)){
					$unique_code = uniqid();
						$query = mysqli_query($conn, "INSERT INTO `tbl_services`(`s_id`, `s_unique_id`, `s_title`, `s_description`, `s_cost`,`s_duration`,  `s_link`, `cover`, `Type`) VALUES ('','$unique_code', '$name', '$description', '$cost', '$duration', '$link', '$uploaded_img', '$category')");
						if ($query) {
						echo "success";
						} else {
							echo "failed to add service!";
						}
			} else {
				echo "Oops, Something went wrong!";
			}
		} else {
			echo "Only '.jpeg', '.jpg', '.png' accepted";
		}

		} else{
			echo "All fields are required!";
		}
		
	} else {
		echo "Service exists";
	}
	} else {
		echo "dsfsd";
	}
?>