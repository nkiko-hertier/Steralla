<?php
    include_once("conn.php");
        // [G]etting form data
        $id        = $_POST['id'];
        $name      = $_POST['name'];
        $role      = $_POST['role'];
        $phone     = $_POST['phone'];
        $email     = $_POST['email'];

        $facebook_link  = explode('/', $_POST['facebook']);
        $Instagram_link = explode('/', $_POST['Instagram']);
        $Twitter_link   = explode('/', $_POST['Twitter']);
        $linkedIn_link  = explode('/', $_POST['linkedIn']);
        $github_link    = explode('/', $_POST['github']);   

        $facebook  = end($facebook_link);
        $Instagram = end($Instagram_link);
        $Twitter   = end($Twitter_link);
        $linkedIn  = end($linkedIn_link);
        $github    = end($github_link);   

        // [G]etting cover picture
        if($_FILES['cover']['name'] !== ''){
            echo "hi, ";
		    $pic_name 	      = $_FILES['cover']['name'];
		    $pic_tmp  	      = $_FILES['cover']['tmp_name'];
            $extensions       =        ["jpeg", "png", "jpg", "PNG", "JPEG", "JPG"];
		    $pic_extension    = pathinfo($pic_name, PATHINFO_EXTENSION);
		    $pic_upload_name  = "snoaw-" . uniqid() . "." . $pic_extension;
		    $destination      = "../../images/uploads/team/" . $pic_upload_name;
            $verify_image     = in_array($pic_extension, $extensions);

            
            $query  = mysqli_query($conn, "SELECT * FROM `tbl_members` WHERE `id`='$id'");
            $cover = "../../images/uploads/team/" . mysqli_fetch_assoc($query)['member_cover_pic'];
            unlink($cover);

                    if($verify_image === true){
                        if(move_uploaded_file($pic_tmp, $destination)){
                            
                        } else {
                            echo "Oops something went wrong!";
                            exit();
                        }

                    } else {
                        echo "Only png jpg or jpeg allowed!";
                        exit();
                    }
        }

        if(!empty($name) && !empty($role) && !empty($facebook) && !empty($linkedIn) && !empty($Twitter)){
            if(!empty($Instagram) && !empty($github)){
                $update_query = "UPDATE `tbl_members` SET `member_name`='$name', `member_role`='$role', `facebook_link`='$facebook', `instagram_link`='$Instagram', `twitter_link`='$Twitter', `linkedin_link`='$linkedIn', `github_link`='$github', `email_address`='$email', `phone_number`='$phone'";
            if (isset($pic_name)) {
                $update_query .= ", `member_cover_pic`='$pic_upload_name'";
            }
            $update_query .= " WHERE `id`='$id'";

            if (mysqli_query($conn, $update_query)) {
                echo "Member was successfully updated!";
            } else {
                echo "Failed to update member!";
            }

            } else {
                echo "Fill one or both Instagram and Github!";
            }
        } else {
            echo "fill all required * fields!";
        }