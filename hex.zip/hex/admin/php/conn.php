<?php
    $db_server = "localhost";
    $db_user   = "root";
	$db_name   = "if0_34717240_bookie";
	$db_pass   = "";
	$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
	$GLOBALS['ROOT'] = "http://localhost/hex/";
	$GLOBALS['SERVICE_URL'] = "images/uploads/services/"

?>