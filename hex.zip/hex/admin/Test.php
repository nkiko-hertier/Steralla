
<?php
    session_start();
	include_once("php/conn.php");
	function countRows($tableName, $conn){
		$sql = mysqli_query($conn, "SELECT * FROM $tableName");
		return mysqli_num_rows($sql);
	} // [USAGE]: echo countRows('tbl_services', $conn);

    function verfyPass($password, $conn){
		$id = $_SESSION['unique_id'];
        $sql_query = mysqli_query($conn, "SELECT * FROM users WHERE `unique_id`='$id'");
        if($sql_query){
            $hash_pass = md5($password);
            $real_pass = mysqli_fetch_assoc($sql_query)['password'];
            if($hash_pass == $real_pass){
                return "true";
            } else {
				echo "Incorrect Password";
			}
        } else {
            return "false";
        }
    }
	echo verfyPass("Afri-games12377", $conn);
?>
